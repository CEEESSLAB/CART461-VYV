var class_wave_packet =
[
    [ "WavePacket", "class_wave_packet.html#a09afa3b26d61c97e24ccbae9cba2fd57", null ],
    [ "next", "class_wave_packet.html#ab4e35082b60d3ccc29c86d09078329bd", null ],
    [ "set", "class_wave_packet.html#ac693b3d676b583584a8cfc6b9cc0f37f", null ],
    [ "setBandwidth", "class_wave_packet.html#abce5b3ca4c559473c199744753fb75aa", null ],
    [ "setCentreFreq", "class_wave_packet.html#adbbbf8b6b9eaae18ef381ff04be3eb5b", null ],
    [ "setFundamental", "class_wave_packet.html#af87c37ffd274eee91aa93c0f7d560be2", null ]
];