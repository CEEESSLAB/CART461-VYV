var class_oscil =
[
    [ "Oscil", "class_oscil.html#afe6a75646d2dd822a654bcd85242e800", null ],
    [ "Oscil", "class_oscil.html#ab7dc5f97742d841fff6a4dca6d7242f3", null ],
    [ "atIndex", "class_oscil.html#a97f2c0f28751641417202fee2a0776d3", null ],
    [ "getPhaseFractional", "class_oscil.html#aa774ef68b06f9652e6ac23d4e9332554", null ],
    [ "next", "class_oscil.html#a655de04690650b27182e3b4d07768d46", null ],
    [ "phaseIncFromFreq", "class_oscil.html#a184110cb1901d2742a6016b46cbea027", null ],
    [ "phMod", "class_oscil.html#a4c6de90bc2d4183a5146eb2ae5e3dd2c", null ],
    [ "setFreq", "class_oscil.html#a23121f22ea447918088a79c7f9748b3d", null ],
    [ "setFreq", "class_oscil.html#aa342e74f8e73edda0b0f042770e3fba4", null ],
    [ "setFreq_Q16n16", "class_oscil.html#a73b52741178ed490463d9ff471cebef3", null ],
    [ "setFreq_Q24n8", "class_oscil.html#abc8a4ee236f7fd45dda9dece7292b6e7", null ],
    [ "setPhase", "class_oscil.html#ab7b740eec56740426a47508562ed4dd5", null ],
    [ "setPhaseFractional", "class_oscil.html#afc77bfc5a1ad5926ad8df37725d480d7", null ],
    [ "setPhaseInc", "class_oscil.html#a2ff9bfcc57e07bf0df2ed7db186ecff7", null ],
    [ "setTable", "class_oscil.html#a0b22d79fb2d6c7fb50b19c00f249ed84", null ]
];